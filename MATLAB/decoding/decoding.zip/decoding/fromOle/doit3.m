load velo2.mat
load pos.mat
load ratio.mat
load ttheta

1
load c3_1     
z = extract(c3_1,ttheta,p,v,ratio); 
save c3_1ex.mat z

2
load c3_2     
z = extract(c3_2,ttheta,p,v,ratio); 
save c3_2ex.mat z

3
load c3_3     
z = extract(c3_3,ttheta,p,v,ratio); 
save c3_3ex.mat z

4
load c3_4     
z = extract(c3_4,ttheta,p,v,ratio); 
save c3_4ex.mat z

5
load c3_5     
z = extract(c3_5,ttheta,p,v,ratio); 
save c3_5ex.mat z

6
load c3_6     
z = extract(c3_6,ttheta,p,v,ratio); 
save c3_6ex.mat z

7
load c3_7     
z = extract(c3_7,ttheta,p,v,ratio); 
save c3_7ex.mat z

8
load c3_8     
z = extract(c3_8,ttheta,p,v,ratio); 
save c3_8ex.mat z


