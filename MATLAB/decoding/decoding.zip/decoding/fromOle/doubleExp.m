function Val = doubleExp(t,tauR,tauF)



Val = exp(-t/tauF)*(1-exp(-t/TauR));
