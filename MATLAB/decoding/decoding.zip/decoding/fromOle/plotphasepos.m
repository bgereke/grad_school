function plotphasepos(w)


for i=1:length(w)



end
