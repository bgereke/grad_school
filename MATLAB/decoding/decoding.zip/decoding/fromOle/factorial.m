function y = factorial(x);


y = prod(1:x);
