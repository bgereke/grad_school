load velo2.mat
load pos.mat
load ratio.mat
load ttheta

1
load c1_1     
z = extract(c1_1,ttheta,p,v,ratio); 
save c1_1ex.mat z

2
load c1_2     
z = extract(c1_2,ttheta,p,v,ratio); 
save c1_2ex.mat z

3
load c1_3     
z = extract(c1_3,ttheta,p,v,ratio); 
save c1_3ex.mat z

4
load c1_4     
z = extract(c1_4,ttheta,p,v,ratio); 
save c1_4ex.mat z

5
load c1_5     
z = extract(c1_5,ttheta,p,v,ratio); 
save c1_5ex.mat z

6
load c1_6     
z = extract(c1_6,ttheta,p,v,ratio); 
save c1_6ex.mat z

7
load c1_7     
z = extract(c1_7,ttheta,p,v,ratio); 
save c1_7ex.mat z

9
load c1_9     
z = extract(c1_9,ttheta,p,v,ratio); 
save c1_9ex.mat z

10
load c1_10    
z = extract(c1_10,ttheta,p,v,ratio); 
save c1_10ex.mat z

11
load c1_11    
z = extract(c1_11,ttheta,p,v,ratio); 
save c1_11ex.mat z

12
load c1_12    
z = extract(c1_12,ttheta,p,v,ratio); 
save c1_12ex.mat z

13
load c1_13    
z = extract(c1_13,ttheta,p,v,ratio); 
save c1_13ex.mat z


