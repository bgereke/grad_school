disp(pwd);
cd begin1
% disp (pwd);
doall_nopaths_SWR
cd ../
clear

cd begin2
% disp (pwd);
doall_nopaths_SWR
cd ../
clear 

cd begin3
% disp (pwd);
doall_nopaths_SWR
cd ../
clear