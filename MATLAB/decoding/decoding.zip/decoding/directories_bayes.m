% %rat 12 directories - linear track
% 
% cd C:\data\Kevin\rat12\2012-01-11_10-16-44;
% cd C:\data\Kevin\rat12\2012-01-12_10-36-30; 
% cd C:\data\Kevin\rat12\2012-01-13_10-26-00;
% cd C:\data\Kevin\rat12\2012-01-14_12-07-04; 
% cd C:\data\Kevin\rat12\2012-01-16_10-10-34; 
% cd C:\data\Kevin\rat12\2012-01-17_09-14-02; doall_envelope;
% % % cd C:\data\Kevin\rat12\2012-01-18_09-51-03; 
% % % cd C:\data\Kevin\rat12\2012-01-19_09-34-41; 
% cd C:\data\Kevin\rat12\2012-01-20_09-22-22; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-21_11-05-25; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-23_11-11-17; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-24_09-17-07; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-25_10-34-35; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-26_09-38-36; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-27_09-00-27; doall_envelope;
cd C:\data\Kevin\rat12\2012-01-28_10-52-54; doall_envelope;
% % %  
% % % %rat 13 directories - linear track
% cd C:\data\Kevin\rat13\2012-01-10_15-28-22; 
% cd C:\data\Kevin\rat13\2012-01-11_12-30-09; 
% cd C:\data\Kevin\rat13\2012-01-12_13-35-07; 
cd C:\data\Kevin\rat13\2012-01-14_13-56-07; doall_envelope;
% cd C:\data\Kevin\rat13\2012-01-16_13-15-43; 
% cd C:\data\Kevin\rat13\2012-01-17_15-21-54; 
cd C:\data\Kevin\rat13\2012-01-18_13-23-57; doall_envelope;
cd C:\data\Kevin\rat13\2012-01-19_12-08-46; doall_envelope;
% cd C:\data\Kevin\rat13\2012-01-20_13-21-04; 
cd C:\data\Kevin\rat13\2012-01-21_13-27-26; doall_envelope;
cd C:\data\Kevin\rat13\2012-01-23_14-39-54; doall_envelope;
% %cd C:\data\Kevin\rat13\2012-01-24_11-43-13; doall_envelope; behaviour too poor
cd C:\data\Kevin\rat13\2012-01-25_13-39-29; doall_envelope;
cd C:\data\Kevin\rat13\2012-01-26_12-32-19; doall_envelope;
cd C:\data\Kevin\rat13\2012-01-27_14-52-44; doall_envelope;
cd C:\data\Kevin\rat13\2012-01-28_12-53-34; doall_envelope;
% 
% % %rat6 directories data
% % %cd C:\data\Kevin\rat6\090311
% cd C:\data\Kevin\rat6\090511\2011-09-05_10-51-21; 
% cd C:\data\Kevin\rat6\090711\2011-09-07_09-07-36; 
% cd C:\data\Kevin\rat6\090911\2011-09-09_12-46-27; 
% cd C:\data\Kevin\rat6\091011\2011-09-10_13-26-30; 
% cd C:\data\Kevin\rat6\091211\2011-09-12_12-04-27; 
% cd C:\data\Kevin\rat6\091311\2011-09-13_10-59-10; 
% cd C:\data\Kevin\rat6\091411\2011-09-14_13-31-33; 
% cd C:\data\Kevin\rat6\091511\2011-09-15_11-07-51; 
% cd C:\data\Kevin\rat6\091711\2011-09-17_12-09-06; 
% cd C:\data\Kevin\rat6\091811\2011-09-18_13-06-19; 
% cd C:\data\Kevin\rat6\091911\2011-09-19_12-59-22; 
% cd C:\data\Kevin\rat6\092011\2011-09-20_11-03-05; 
% cd C:\data\Kevin\rat6\092111\2011-09-21_10-52-10; 
% cd C:\data\Kevin\rat6\092211\2011-09-22_11-22-02; 
cd C:\data\Kevin\rat6\092311\2011-09-23_08-51-24; doall_envelope;
% cd C:\data\Kevin\rat6\092411\2011-09-24_17-26-58; 
% cd C:\data\Kevin\rat6\092511\2011-09-25_13-02-55; 
% cd C:\data\Kevin\rat6\092611\2011-09-26_11-48-23; 
% cd C:\data\Kevin\rat6\092711\2011-09-27_11-12-41; 
% cd C:\data\Kevin\rat6\092811\2011-09-28_12-35-46; 
cd C:\data\Kevin\rat6\092911\2011-09-29_11-29-11; doall_envelope;
cd C:\data\Kevin\rat6\093011\2011-09-30_13-26-23; doall_envelope;
cd C:\data\Kevin\rat6\100111\2011-10-01_12-14-23; doall_envelope;
cd C:\data\Kevin\rat6\100211\2011-10-02_12-12-23; doall_envelope;
cd C:\data\Kevin\rat6\100311\2011-10-03_12-02-29; doall_envelope;
cd C:\data\Kevin\rat6\100411\2011-10-04_11-25-44; doall_envelope;
cd C:\data\Kevin\rat6\100511\2011-10-05_11-37-03; doall_envelope;
cd C:\data\Kevin\rat6\100611\2011-10-06_11-28-23; doall_envelope;
cd C:\data\Kevin\rat6\100711\2011-10-07_12-04-20; doall_envelope;
cd C:\data\Kevin\rat6\100811\2011-10-08_12-07-54; doall_envelope;
cd C:\data\Kevin\rat6\100911\2011-10-09_11-58-05; doall_envelope;
cd C:\data\Kevin\rat6\101011\2011-10-10_11-58-33; doall_envelope;
cd C:\data\Kevin\rat6\101111\2011-10-11_11-41-02; doall_envelope;
% cd C:\data\Kevin\rat6\101211\2011-10-12_11-48-53; 
% 
% 
% %rat17
cd E:\Kevin\rat17\2012-06-05_10-12-59; doall_envelope;
% cd E:\Kevin\rat17\2012-06-06_09-39-41; 
% cd E:\Kevin\rat17\2012-06-07_10-35-15; 
% cd E:\Kevin\rat17\2012-06-08_09-49-24; 
% cd E:\Kevin\rat17\2012-06-09_09-57-58; 
% cd E:\Kevin\rat17\2012-06-11_09-35-20; 
% cd E:\Kevin\rat17\2012-06-12_09-33-58; 
% cd E:\Kevin\rat17\2012-06-13_09-46-44; 
cd E:\Kevin\rat17\2012-06-14_09-35-44; doall_envelope;
cd E:\Kevin\rat17\2012-06-20_10-24-32; doall_envelope;
cd E:\Kevin\rat17\2012-06-21_10-31-26; doall_envelope;
cd E:\Kevin\rat17\2012-06-22_10-39-32; doall_envelope;
cd E:\Kevin\rat17\2012-06-23_11-18-48; doall_envelope;
cd E:\Kevin\rat17\2012-06-25_10-41-18; doall_envelope;
cd E:\Kevin\rat17\2012-06-26_10-48-05; doall_envelope;
cd E:\Kevin\rat17\2012-06-27_10-59-30; doall_envelope;
cd E:\Kevin\rat17\2012-06-28_10-41-40; doall_envelope;
cd E:\Kevin\rat17\2012-06-29_10-52-43; doall_envelope;
cd E:\Kevin\rat17\2012-06-30_11-49-24; doall_envelope;
cd E:\Kevin\rat17\2012-07-02_10-25-29; doall_envelope;
% 
% %ratChris
% cd C:\data\Kevin\Chris2\2013-04-07_13-21-21; 
% cd C:\data\Kevin\Chris2\2013-04-08_11-10-51; 
% cd C:\data\Kevin\Chris2\2013-04-09_11-14-22; 
% cd C:\data\Kevin\Chris2\2013-04-10_10-55-22; 
% cd C:\data\Kevin\Chris2\2013-04-11_10-14-19\begin1; 
% cd C:\data\Kevin\Chris2\2013-04-12_08-21-04; 
% cd C:\data\Kevin\Chris2\2013-04-14_12-16-07; 
% cd C:\data\Kevin\Chris2\2013-04-15_09-03-20; 
% cd C:\data\Kevin\Chris2\2013-04-16_09-48-23; 
% cd C:\data\Kevin\Chris2\2013-04-17_13-08-26; 
% cd C:\data\Kevin\Chris2\2013-04-18_09-18-08; 
% cd C:\data\Kevin\Chris2\2013-04-19_14-31-42; 
% cd C:\data\Kevin\Chris2\2013-04-21_15-33-52; 